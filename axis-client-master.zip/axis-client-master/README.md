Project Ini dibuat dengan [Create React App](https://github.com/facebook/create-react-app).

## `DEMO`
Visit [https://axis-client-rg0ppr6h5.now.sh/](https://axis-client-rg0ppr6h5.now.sh/)

## `INSTALL`

### `git clone https://github.com/adipatiarya/axis-client.git`
###  `cd axis-client`

### `npm install`
Menginstall Semua dependecy yg dibutuhkan.

### `npm start`

Menjalankan Aplikasi pada dev mode.<br />
Buka [http://localhost:3000](http://localhost:3000) untuk  melihat di browser.

Halaman akan direload Jika anda melakukan pengeditan.<br />
Anda juga akan melihat log error di terminal atau cmd.

### `npm run build`

Build aplikasi berada di  folder `build`.<br />
Anda bisa menguploadnya di server apache nginix, dll.


## `KURSUS ONLINE Free`

Anda bisa belajar dari 0 untuk bisa membuat app semacam ini [CALON MASTA SECTION 1](https://web.facebook.com/groups/calonmasta.section01/).

Untuk belajar Java script dari 0, Diajarin langsung oleh saya melalui live video.

## `KURSUS ONLINE Lanjutan`

Group lanjutan se [CALON MASTA SECTION 2](https://web.facebook.com/groups/calonmasta.section01/).

Secara garis Besar mempelajari tentang basic HTML , basic javascript , frontend Menggunakan React, backend Menggunakan nodejs, Firebase ,Upload ke server

Dikenakan biaya Rp 1jt diajarkan dari 0 sampe bener2 bisa dengan tujuan supaya serius belajar bukan sekedar iseng2. 


YANG MAU JOIN BELAJAR [LINK FB](https://web.facebook.com/adipati.aarya).
atau CONTACT WA VIA 0812 9120 2810.

